import java.io.BufferedReader;
import java.io.File;

public class FileReader {
    public static void readProducts(String filePath){
        File file = new File(filePath);
        BufferedReader reader = null;
    }
}
