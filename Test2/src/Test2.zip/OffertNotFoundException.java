public class OffertNotFoundException extends Exception {
    public OffertNotFoundException(){
    }
    public OffertNotFoundException(String msg){
        super(msg);
    }
}
